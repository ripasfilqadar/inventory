
    <section id="rekapitulasi" class="info">

        <div class="info-section-gray">

            <div class="container">
                <header>
                    <h1>SMP Negeri</h1>
                </header>
                <div class="row">

                    <div class="col-md-12">
                        <table class="table table-bordered table-hover table-striped">
                            <thead style="background-color: #dde4e6; font-weight: 700; text-align: center;">
                                <tr>
                                    <td>Kode</td>
                                    <td>Nama Sekolah</td>
                                    <td>Pagu</td>
                                    <td>Nilai Max</td>
                                    <td>Nilai Min</td>
                                    <td>Pagu Terisi</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>

                                    <td>02</td>

                                    <td>SMP Negeri 2 Sidoarjo</td>

                                    <td>241</td>

                                    <td>27.57</td>

                                    <td>23.38</td>

                                    <td>241</td>

                                </tr>

                                            <tr>

                                    <td>03</td>

                                    <td>SMP Negeri 3 Sidoarjo</td>

                                    <td>240</td>

                                    <td>27.72</td>

                                    <td>24.05</td>

                                    <td>240</td>

                                </tr>

                                            <tr>

                                    <td>04</td>

                                    <td>SMP Negeri 4 Sidoarjo</td>

                                    <td>278</td>

                                    <td>27.45</td>

                                    <td>22.54</td>

                                    <td>278</td>

                                </tr>

                                            <tr>

                                    <td>05</td>

                                    <td>SMP Negeri 5 Sidoarjo</td>

                                    <td>208</td>

                                    <td>27.87</td>

                                    <td>23.65</td>

                                    <td>208</td>

                                </tr>

                                            <tr>

                                    <td>06</td>

                                    <td>SMP Negeri 6 Sidoarjo</td>

                                    <td>210</td>

                                    <td>27.03</td>

                                    <td>22.21</td>

                                    <td>210</td>

                                </tr>

                                            <tr>

                                    <td>07</td>

                                    <td>SMP Negeri 1 Buduran</td>

                                    <td>288</td>

                                    <td>27.35</td>

                                    <td>21.68</td>

                                    <td>288</td>

                                </tr>

                                            <tr>

                                    <td>08</td>

                                    <td>SMP Negeri 2 Buduran</td>

                                    <td>249</td>

                                    <td>26.06</td>

                                    <td>21.43</td>

                                    <td>249</td>

                                </tr>

                                            <tr>

                                    <td>09</td>

                                    <td>SMP Negeri 1 Candi</td>

                                    <td>242</td>

                                    <td>27.84</td>

                                    <td>23.23</td>

                                    <td>242</td>

                                </tr>

                                            <tr>

                                    <td>10</td>

                                    <td>SMP Negeri 2 Candi</td>

                                    <td>276</td>

                                    <td>27.87</td>

                                    <td>21.97</td>

                                    <td>276</td>

                                </tr>

                                            <tr>

                                    <td>11</td>

                                    <td>SMP Negeri 3 Candi</td>

                                    <td>211</td>

                                    <td>26.25</td>

                                    <td>22.73</td>

                                    <td>211</td>

                                </tr>

                                            <tr>

                                    <td>12</td>

                                    <td>SMP Negeri 1 Porong</td>

                                    <td>282</td>

                                    <td>27.41</td>

                                    <td>20.30</td>

                                    <td>282</td>

                                </tr>

                                            <tr>

                                    <td>13</td>

                                    <td>SMP Negeri 2 Porong</td>

                                    <td>240</td>

                                    <td>24.03</td>

                                    <td>19.76</td>

                                    <td>240</td>

                                </tr>

                                            <tr>

                                    <td>14</td>

                                    <td>SMP Negeri 3 Porong</td>

                                    <td>216</td>

                                    <td>27.03</td>

                                    <td>20.23</td>

                                    <td>216</td>

                                </tr>

                                            <tr>

                                    <td>15</td>

                                    <td>SMP Negeri 1 Krembung</td>

                                    <td>252</td>

                                    <td>25.35</td>

                                    <td>20.29</td>

                                    <td>252</td>

                                </tr>

                                            <tr>

                                    <td>16</td>

                                    <td>SMP Negeri 2 Krembung</td>

                                    <td>286</td>

                                    <td>26.12</td>

                                    <td>20.11</td>

                                    <td>286</td>

                                </tr>

                                            <tr>

                                    <td>17</td>

                                    <td>SMP Negeri 1 Tulangan</td>

                                    <td>355</td>

                                    <td>26.85</td>

                                    <td>21.29</td>

                                    <td>355</td>

                                </tr>

                                            <tr>

                                    <td>18</td>

                                    <td>SMP Negeri 1 Tanggulangin</td>

                                    <td>251</td>

                                    <td>25.56</td>

                                    <td>21.42</td>

                                    <td>251</td>

                                </tr>

                                            <tr>

                                    <td>19</td>

                                    <td>SMP Negeri 2 Tanggulangin</td>

                                    <td>177</td>

                                    <td>24.76</td>

                                    <td>21.12</td>

                                    <td>177</td>

                                </tr>

                                            <tr>

                                    <td>20</td>

                                    <td>SMP Negeri 1 Jabon</td>

                                    <td>286</td>

                                    <td>26.49</td>

                                    <td>18.67</td>

                                    <td>286</td>

                                </tr>

                                            <tr>

                                    <td>21</td>

                                    <td>SMP Negeri 2 Jabon</td>

                                    <td>228</td>

                                    <td>25.36</td>

                                    <td>20.38</td>

                                    <td>228</td>

                                </tr>

                                            <tr>

                                    <td>22</td>

                                    <td>SMP Negeri 1 Krian</td>

                                    <td>283</td>

                                    <td>27.00</td>

                                    <td>21.30</td>

                                    <td>283</td>

                                </tr>

                                            <tr>

                                    <td>23</td>

                                    <td>SMP Negeri 2 Krian</td>

                                    <td>320</td>

                                    <td>27.03</td>

                                    <td>21.01</td>

                                    <td>320</td>

                                </tr>

                                            <tr>

                                    <td>24</td>

                                    <td>SMP Negeri 3 Krian</td>

                                    <td>288</td>

                                    <td>26.22</td>

                                    <td>20.63</td>

                                    <td>288</td>

                                </tr>

                                            <tr>

                                    <td>25</td>

                                    <td>SMP Negeri 1 Balongbendo</td>

                                    <td>251</td>

                                    <td>25.71</td>

                                    <td>20.36</td>

                                    <td>251</td>

                                </tr>

                                            <tr>

                                    <td>26</td>

                                    <td>SMP Negeri 2 Balongbendo</td>

                                    <td>180</td>

                                    <td>22.55</td>

                                    <td>19.30</td>

                                    <td>180</td>

                                </tr>

                                            <tr>

                                    <td>27</td>

                                    <td>SMP Negeri 1 Tarik</td>

                                    <td>251</td>

                                    <td>26.20</td>

                                    <td>20.25</td>

                                    <td>251</td>

                                </tr>

                                            <tr>

                                    <td>28</td>

                                    <td>SMP Negeri 2 Tarik</td>

                                    <td>216</td>

                                    <td>25.39</td>

                                    <td>19.27</td>

                                    <td>216</td>

                                </tr>

                                            <tr>

                                    <td>29</td>

                                    <td>SMP Negeri 1 Prambon</td>

                                    <td>248</td>

                                    <td>25.83</td>

                                    <td>20.34</td>

                                    <td>248</td>

                                </tr>

                                            <tr>

                                    <td>30</td>

                                    <td>SMP Negeri 1 Wonoayu</td>

                                    <td>320</td>

                                    <td>26.61</td>

                                    <td>21.32</td>

                                    <td>320</td>

                                </tr>

                                            <tr>

                                    <td>31</td>

                                    <td>SMP Negeri 2 Wonoayu</td>

                                    <td>210</td>

                                    <td>25.30</td>

                                    <td>20.28</td>

                                    <td>210</td>

                                </tr>

                                            <tr>

                                    <td>32</td>

                                    <td>SMP Negeri 1 Taman</td>

                                    <td>315</td>

                                    <td>27.40</td>

                                    <td>22.23</td>

                                    <td>315</td>

                                </tr>

                                            <tr>

                                    <td>33</td>

                                    <td>SMP Negeri 2 Taman</td>

                                    <td>347</td>

                                    <td>27.26</td>

                                    <td>21.26</td>

                                    <td>347</td>

                                </tr>

                                            <tr>

                                    <td>34</td>

                                    <td>SMP Negeri 3 Taman</td>

                                    <td>211</td>

                                    <td>25.80</td>

                                    <td>20.51</td>

                                    <td>211</td>

                                </tr>

                                            <tr>

                                    <td>35</td>

                                    <td>SMP Negeri 1 Sukodono</td>

                                    <td>319</td>

                                    <td>25.65</td>

                                    <td>20.57</td>

                                    <td>319</td>

                                </tr>

                                            <tr>

                                    <td>36</td>

                                    <td>SMP Negeri 2 Sukodono</td>

                                    <td>247</td>

                                    <td>25.75</td>

                                    <td>20.22</td>

                                    <td>247</td>

                                </tr>

                                            <tr>

                                    <td>37</td>

                                    <td>SMP Negeri 1 Gedangan</td>

                                    <td>284</td>

                                    <td>26.90</td>

                                    <td>20.37</td>

                                    <td>284</td>

                                </tr>

                                            <tr>

                                    <td>38</td>

                                    <td>SMP Negeri 2 Gedangan</td>

                                    <td>319</td>

                                    <td>25.65</td>

                                    <td>20.26</td>

                                    <td>319</td>

                                </tr>

                                            <tr>

                                    <td>39</td>

                                    <td>SMP Negeri 1 Waru</td>

                                    <td>314</td>

                                    <td>27.18</td>

                                    <td>21.18</td>

                                    <td>314</td>

                                </tr>

                                            <tr>

                                    <td>40</td>

                                    <td>SMP Negeri 2 Waru</td>

                                    <td>247</td>

                                    <td>26.46</td>

                                    <td>20.41</td>

                                    <td>247</td>

                                </tr>

                                            <tr>

                                    <td>41</td>

                                    <td>SMP Negeri 3 Waru</td>

                                    <td>258</td>

                                    <td>27.03</td>

                                    <td>21.15</td>

                                    <td>258</td>

                                </tr>

                                            <tr>

                                    <td>42</td>

                                    <td>SMP Negeri 4 Waru</td>

                                    <td>209</td>

                                    <td>26.91</td>

                                    <td>21.25</td>

                                    <td>209</td>

                                </tr>

                                            <tr>

                                    <td>43</td>

                                    <td>SMP Negeri 1 Sedati</td>

                                    <td>175</td>

                                    <td>26.88</td>

                                    <td>21.27</td>

                                    <td>175</td>

                                </tr>

                                            <tr>

                                    <td>44</td>

                                    <td>SMP Negeri 2 Sedati</td>

                                    <td>280</td>

                                    <td>27.12</td>

                                    <td>19.86</td>

                                    <td>280</td>

                                </tr>

                            </tbody>
                        </table>

                    </div> 

                </div>

                <header>
                    <h1>SMA Negeri</h1>
                </header>
                <div class="row">

                    <div class="col-md-12">
                        <table class="table table-bordered table-hover table-striped">
                            <thead style="background-color: #dde4e6; font-weight: 700; text-align: center;">
                                <tr>
                                    <td>Kode</td>
                                    <td>Nama Sekolah</td>
                                    <td>Pagu</td>
                                    <td>Nilai Max</td>
                                    <td>Nilai Min</td>
                                    <td>Pagu Terisi</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>

                                    <td>52</td>

                                    <td>SMA Negeri 2 Sidoarjo</td>

                                    <td>155</td>

                                    <td>33.94</td>

                                    <td>30.40</td>

                                    <td>155</td>

                                </tr>

                                            <tr>

                                    <td>53</td>

                                    <td>SMA Negeri 3 Sidoarjo</td>

                                    <td>270</td>

                                    <td>33.73</td>

                                    <td>31.54</td>

                                    <td>270</td>

                                </tr>

                                            <tr>

                                    <td>54</td>

                                    <td>SMA Negeri 4 Sidoarjo</td>

                                    <td>268</td>

                                    <td>33.90</td>

                                    <td>30.14</td>

                                    <td>268</td>

                                </tr>

                                            <tr>

                                    <td>55</td>

                                    <td>SMA Negeri 1 Porong</td>

                                    <td>240</td>

                                    <td>33.00</td>

                                    <td>29.21</td>

                                    <td>240</td>

                                </tr>

                                            <tr>

                                    <td>56</td>

                                    <td>SMA Negeri 1 Krembung</td>

                                    <td>281</td>

                                    <td>33.40</td>

                                    <td>28.86</td>

                                    <td>281</td>

                                </tr>

                                            <tr>

                                    <td>58</td>

                                    <td>SMA Negeri 1 Taman</td>

                                    <td>276</td>

                                    <td>33.64</td>

                                    <td>28.70</td>

                                    <td>276</td>

                                </tr>

                                            <tr>

                                    <td>59</td>

                                    <td>SMA Negeri 1 Waru</td>

                                    <td>230</td>

                                    <td>32.43</td>

                                    <td>28.58</td>

                                    <td>230</td>

                                </tr>

                                            <tr>

                                    <td>60</td>

                                    <td>SMA Negeri 1 Gedangan</td>

                                    <td>271</td>

                                    <td>33.69</td>

                                    <td>29.48</td>

                                    <td>271</td>

                                </tr>

                                            <tr>

                                    <td>61</td>

                                    <td>SMA Negeri 1 Wonoayu</td>

                                    <td>247</td>

                                    <td>32.25</td>

                                    <td>29.21</td>

                                    <td>247</td>

                                </tr>

                                            <tr>

                                    <td>62</td>

                                    <td>SMA Negeri 1 Tarik</td>

                                    <td>173</td>

                                    <td>32.76</td>

                                    <td>28.42</td>

                                    <td>173</td>

                                </tr>

                            </tbody>
                        </table>

                    </div> 

                </div>

                <header>
                    <h1>SMK Negeri</h1>
                </header>
                <div class="row">

                    <div class="col-md-12">
                        <table class="table table-bordered table-hover table-striped">
                            <thead style="background-color: #dde4e6; font-weight: 700; text-align: center;">
                                <tr>
                                    <td>Kode</td>
                                    <td>Nama Sekolah</td>
                                    <td>Program Keahlian</td>
                                    <td>Pagu</td>
                                    <td>Nilai Max</td>
                                    <td>Nilai Min</td>
                                    <td>Pagu Terisi</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>

                                    <td>71</td>

                                    <td colspan="6">SMK Negeri 1 Sidoarjo</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>T. GAMBAR BANGUNAN</td>

                                    <td>396</td>

                                    <td>58.72</td>

                                    <td>50.92</td>

                                    <td>396</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>T. KONSTRUKSI KAYU</td>

                                    <td>396</td>

                                    <td>52.54</td>

                                    <td>49.42</td>

                                    <td>396</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>T. INSTALASI TENAGA LISTRIK</td>

                                    <td>396</td>

                                    <td>58.77</td>

                                    <td>51.86</td>

                                    <td>396</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>T. AUDIO VIDEO</td>
                     
                                    <td>396</td>

                                    <td>57.74</td>

                                    <td>51.70</td>

                                    <td>396</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>T. PENDINGIN DAN TATA UDARA</td>

                                    <td>396</td>

                                    <td>56.83</td>

                                    <td>51.62</td>

                                    <td>396</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>T. PERMESINAN</td>

                                    <td>396</td>

                                    <td>57.86</td>

                                    <td>52.06</td>

                                    <td>396</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>T. KENDARAAN RINGAN</td>

                                    <td>396</td>

                                    <td>59.27</td>

                                    <td>52.67</td>

                                    <td>396</td>

                                </tr>

                                                        <tr>

                                    <td>72</td>

                                    <td colspan="6">SMK Negeri 1 Buduran</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>JASA BOGA</td>

                                    <td>371</td>

                                    <td>52.59</td>

                                    <td>41.34</td>

                                    <td>371</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>BUSANA BUTIK</td>

                                    <td>371</td>

                                    <td>64.36</td>

                                    <td>38.90</td>

                                    <td>371</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>AKOMODASI PERHOTELAN</td>

                                    <td>371</td>

                                    <td>53.77</td>

                                    <td>45.31</td>

                                    <td>371</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>TATA KECANTIKAN RAMBUT</td>

                                    <td>371</td>

                                    <td>55.28</td>

                                    <td>41.34</td>

                                    <td>371</td>

                                </tr>

                                                        <tr>

                                    <td>73</td>

                                    <td colspan="6">SMK Negeri 2 Buduran</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>AKUNTANSI</td>

                                    <td>432</td>

                                    <td>55.86</td>

                                    <td>49.32</td>

                                    <td>432</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>ADMINISTRASI PERKANTORAN</td>

                                    <td>432</td>

                                    <td>54.47</td>

                                    <td>49.18</td>

                                    <td>432</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>PEMASARAN</td>

                                    <td>432</td>

                                    <td>53.04</td>

                                    <td>47.52</td>

                                    <td>432</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>REKAYASA PERANGKAT LUNAK</td>

                                    <td>432</td>

                                    <td>53.82</td>

                                    <td>48.71</td>

                                    <td>432</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>MULTIMEDIA</td>

                                    <td>432</td>

                                    <td>56.22</td>

                                    <td>49.19</td>

                                    <td>432</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>PERBANKAN</td>

                                    <td>432</td>

                                    <td>53.30</td>

                                    <td>48.12</td>

                                    <td>432</td>

                                </tr>

                                                        <tr>

                                    <td>74</td>

                                    <td colspan="6">SMK Negeri 3 Buduran</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>T. MESIN PERKAKAS</td>

                                    <td>424</td>

                                    <td>63.17</td>

                                    <td>54.62</td>

                                    <td>424</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>T. MEKANIK OTOMOTIF</td>

                                    <td>424</td>

                                    <td>65.34</td>

                                    <td>56.47</td>

                                    <td>424</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>T. PENDINGIN DAN TATA UDARA</td>

                                    <td>424</td>

                                    <td>58.50</td>

                                    <td>54.11</td>

                                    <td>424</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>T. KOMPUTER DAN JARINGAN</td>

                                    <td>424</td>

                                    <td>64.40</td>

                                    <td>57.80</td>

                                    <td>424</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>PEMBANGUNAN DAN PERBAIKAN KAPAL</td>

                                    <td>424</td>

                                    <td>61.38</td>

                                    <td>53.43</td>

                                    <td>424</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>I. PERMESINAN KAPAL</td>

                                    <td>424</td>

                                    <td>61.77</td>

                                    <td>54.34</td>

                                    <td>424</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>T. LAS KAPAL</td>

                                    <td>424</td>

                                    <td>61.24</td>

                                    <td>55.48</td>

                                    <td>424</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>LISTRIK KAPAL</td>

                                    <td>424</td>

                                    <td>62.79</td>

                                    <td>55.95</td>

                                    <td>424</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>INTERIOR KAPAL</td>

                                    <td>424</td>

                                    <td>58.58</td>

                                    <td>53.74</td>

                                    <td>424</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>RANCANG BANGUN KAPAL</td>

                                    <td>424</td>

                                    <td>61.52</td>

                                    <td>54.42</td>

                                    <td>424</td>

                                </tr>

                                                        <tr>

                                    <td>75</td>

                                    <td colspan="6">SMK Negeri 1 Jabon</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>TEKNIK OTOMOTIF</td>

                                    <td>180</td>

                                    <td>58.86</td>

                                    <td>48.88</td>

                                    <td>180</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>TEKNIK ELEKTRO</td>

                                    <td>180</td>

                                    <td>59.95</td>

                                    <td>46.44</td>

                                    <td>180</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>MULTIMEDIA</td>

                                    <td>180</td>

                                    <td>59.04</td>

                                    <td>51.32</td>

                                    <td>180</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>TATA BUSANA</td>

                                    <td>180</td>

                                    <td>56.86</td>

                                    <td>46.60</td>

                                    <td>180</td>

                                </tr>

                                            <tr>

                                    <td colspan="2"></td>

                                    <td>KRIA TEKSTIL</td>

                                    <td>180</td>

                                    <td>51.14</td>

                                    <td>40.15</td>

                                    <td>180</td>

                                </tr>

                            </tbody>
                        </table>

                    </div> 

                </div>
            </div>

        </div>

    </section>
