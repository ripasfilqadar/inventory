
    <section id="main-content">

        <div class="container">

            <div class="icon-huge">
                <img src="<?php echo base_url(); ?>images/icons/compas.svg" alt="" />
            </div>

            <header>
                <h1>Halaman tidak ditemukan!</h1>
                <p class="lead">Anda sedang mengakses halaman yang tidak ada di situs ini. Halaman yang sedang anda cari mungkin sudah dihapus atau dipindahkan. Ingin kembali ke halaman utama?</p>
                <br>
                <a href="<?php echo base_url(); ?>" class="btn btn-hg btn-primary btn-embossed text-center"><span class="fui-arrow-left"></span> Kembali ke Halaman Utama</a>
            </header>

        </div> 

    </section>