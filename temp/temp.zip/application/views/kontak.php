    <section id="kontak">

        <div class="container">

            <header>
                <h1>Kontak</h1>
            </header>

            <div class="row">

                <div class="col-md-3">
                </div>
                <div class="col-md-6">

                    <div class="palette palette-emerald">
                        
                        <p class="lead" style="color: #fff">Kontak Kami</p>
                        <div class="row">
                          
                          <div class="col-md-4 col-xs-6 text-left">
                            <strong>Alamat</strong>
                          </div>
                          
                          <div class="col-md-8 col-xs-6">
                            <address>
                              Dinas Pendidikan Kabupaten Sidoarjo <br>
                              JL. Pahlawan 4, Sidoarjo, Jawa Timur.
                            </address>
                          </div>

                        </div>

                        <div class="row">
                          
                          <div class="col-md-4 col-xs-6 text-left">
                            <strong>Telpon</strong>
                          </div>
                          
                          <div class="col-md-8 col-xs-6">
                            <address>
                              <a href="tel:0318921219" style="color: #fff">031-8921219</a><br>
                            </address>
                          </div>

                        </div>

                    </div>

                </div>
                
            </div>
        </div>

    </section>
