    <section id="footer">
        <div class="bottom-menu-inverse">

            <div class="container">

                <div class="row">
                    <div class="col-md-6">
                        <p>Copyright &copy; <a href="<?php echo base_url(); ?>" class="footer-link" target="_blank">PPDB Sidoarjo 2014</a> | <a href="www.dispendiksidoarjo.net/" target="_blank" class="footer-link">Dinas Pendidikan Kabupaten Sidoarjo</a><br>
                        Didukung oleh: <a href="http://its.ac.id" target="_blank" class="footer-link">Institut Teknologi Sepuluh Nopember Surabaya</a></p>
                    </div>
                </div>
            
            </div>
        </div>

    </section>

    <script src="<?php echo base_url(); ?>js/jquery-1.8.3.min.js"></script>
    <script src="<?php echo base_url(); ?>js/jquery-ui-1.10.3.custom.min.js"></script>
    <script src="<?php echo base_url(); ?>js/jquery.ui.touch-punch.min.js"></script>
    <script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>js/jquery.isotope.min.js"></script>
    <script src="<?php echo base_url(); ?>js/jquery.magnific-popup.js"></script>
    <script src="<?php echo base_url(); ?>js/jquery.fitvids.min.js"></script>
    <script src="<?php echo base_url(); ?>js/bootstrap-select.js"></script>
    <script src="<?php echo base_url(); ?>js/bootstrap-switch.js"></script>
    <script src="<?php echo base_url(); ?>js/flatui-checkbox.js"></script>
    <script src="<?php echo base_url(); ?>js/flatui-radio.js"></script>
    <script src="<?php echo base_url(); ?>js/jquery.tagsinput.js"></script>
    <script src="<?php echo base_url(); ?>js/jquery.placeholder.js"></script>
    <script src="<?php echo base_url(); ?>js/custom.js"></script>

  </body>
</html>
